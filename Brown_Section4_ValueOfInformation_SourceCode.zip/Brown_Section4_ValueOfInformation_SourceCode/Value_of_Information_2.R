# Find the histogram of the critical uncertainty for each decision pathway.
dec1.branch.hist <- hist(dec1.uncs$peak.units.sold, plot = TRUE)
dec2.branch.hist <- hist(dec2.uncs$peak.units.sold, plot = TRUE)

# Find the midpoints of the bins.
dec1.branch.bins <- dec1.branch.hist$mids
dec2.branch.bins <- dec2.branch.hist$mids

# Find the fequency of the bins in the histograms.
dec1.branch.cnts <- dec1.branch.hist$counts
dec1.branch.probs <- dec1.branch.cnts / samps

dec2.branch.cnts <- dec2.branch.hist$counts
dec2.branch.probs <- dec2.branch.cnts / samps

# Find the sensitivity of the NPV to the midpoints of the bins in each
# uncertainty.
bdm1.sens <- c(0)
for (b in 1:length(dec1.branch.bins)) {
  bdm1.sens[b] <- mean(
    CalcBizModel(
      time,
      samps,
      rep(dec1.branch.bins[b], samps),
      dec1.uncs$time.to.peak,
      dec1.uncs$price,
      dec1.uncs$sga,
      dec1.uncs$cogs,
      tax.rate,
      dec1.uncs$investment,
      disc.rate
    )$npv / 1e6
  )
}

bdm2.sens <- c(0)
for (b in 1:length(dec2.branch.bins)) {
  bdm2.sens[b] <- mean(
    CalcBizModel(
      time,
      samps,
      rep(dec2.branch.bins[b], samps),
      dec2.uncs$time.to.peak,
      dec2.uncs$price,
      dec2.uncs$sga,
      dec2.uncs$cogs,
      tax.rate,
      dec2.uncs$investment,
      disc.rate
    )$npv / 1e6
  )
}

# Create the MxN matrix of the products of the uncertainty branch probabilities.
probs.branch.matrix <- dec1.branch.probs %*% t(dec2.branch.probs)

# Create a MxN matrix of the values in the bdm1.sens and bdm2.sens vectors.
# Transpose the values in the second matrix
bdm1.sens.matrix <-
  array(rep(bdm1.sens, length(dec2.branch.probs)),
        dim = c(length(dec1.branch.probs), length(dec2.branch.probs)))

bdm2.sens.matrix <-
  t(array(rep(bdm2.sens, length(dec1.branch.probs)),
          dim = c(length(dec2.branch.probs), length(dec1.branch.probs)
  )))

# Find the parallel maximum value between these matrices. This represents
# knowing the maximum value given the prior information about the combinations
# of the outcomes of each uncertainty.
bdm.sens.prior.info <- pmax(bdm1.sens.matrix, bdm2.sens.matrix)

# Find the expected value of the matrix that contains the decision values with
# prior information. This is the value of knowing the outcome before making a
# decision.
bdm.prior.info <- sum(bdm.sens.prior.info * probs.branch.matrix)

# Find the maximum expected decison value without prior information.
bdm.max.curr.info <- max(mean(bdm1), mean(bdm2))

# The value of information is the net value of knowing
# the outcome beforehand compared to the decison with
# the highest value before the outcome is known.
val.info <- (bdm.prior.info - bdm.max.curr.info)

print("Decision Value [$M]")
value.report <- list("Prior Information" = signif(bdm.prior.info, 3),
                     "Current Information" = signif(bdm.max.curr.info, 3),
                     "Value of Information" = signif(val.info, 3))
print(value.report)
