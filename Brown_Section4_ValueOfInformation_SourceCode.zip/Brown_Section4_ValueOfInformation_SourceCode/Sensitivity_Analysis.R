# time -> the time index, year
# peak units sold -> uncertainty
# time to peak units sold -> uncertainty, years
# price -> uncertainty, $/unit
# sales, general, and admin -> uncertainty, % revenue
# cost of goods sold -> uncertainty, $/unit
# tax rate -> % profit
# initial investment -> uncertainty, $
# discount rate -> %/year

# Create a vector of values representing the sensitivity quantiles.
sens.range <- c(0.1, 0.5, 0.9)

npv.sens1 <- CalcModelSensitivity(
  unc.list = dec1.uncs,
  sens.q = sens.range
) / 1e6

npv.sens2 <- CalcModelSensitivity(
  unc.list = dec2.uncs,
  sens.q = sens.range
) / 1e6

print("Decision 1 Sensitivity to Uncertainty [$M]")
print(signif(npv.sens1[, c(1, length(sens.range))], 3))

print("Decision 2 Sensitivity to Uncertainty [$M]")
print(signif(npv.sens2[, c(1, length(sens.range))], 3))

# Find the rank order the uncertainties by the declining range of variation
# they cause in the NPV. Base this on the decision with the highest mean value.
mean.bdm.list <- c(m.bdm1, m.bdm2)
bdm.sensitivity.list <- list(npv.sens1, npv.sens2)
npv.sens.rank <-
  order(abs(bdm.sensitivity.list[[which.max(mean.bdm.list)]][, 1] -
              bdm.sensitivity.list[[which.max(mean.bdm.list)]][, length(sens.range)]),
        decreasing = FALSE)

# Reorder the variables in the sensitivity arrays and names array by the rank
# order.
ranked.npv.sens2 <- npv.sens2[npv.sens.rank, c(1, length(sens.range))]
ranked.npv.sens1 <- npv.sens1[npv.sens.rank, c(1, length(sens.range))]

# Plot the tornado chart for Decision2
par(mai = c(1, 1.75, .5, .5))
barplot(
  t(ranked.npv.sens2) - m.bdm2,
  main = "NPV Sensitivity to Uncertainty Ranges",
  names.arg = names(ranked.npv.sens2),
  col = "blue",
  xlim = c(min(npv.sens1, npv.sens2), max(npv.sens1, npv.sens2)),
  xlab = "Decision2 NPV [$M]",
  beside = TRUE,
  horiz = TRUE,
  offset = m.bdm2,
  las = 1,
  space = c(-1, 1),
  cex.names = 1
)

# Plot the tornado chart for Decision1
par(mai = c(1, 1.75, .5, .5))
barplot(
  t(ranked.npv.sens1) - m.bdm1,
  main = "NPV Sensitivity to Uncertainty Ranges",
  names.arg = names(ranked.npv.sens1),
  col = "red",
  xlim = c(min(npv.sens1, npv.sens2), max(npv.sens1, npv.sens2)),
  xlab = "Decision1 NPV [$M]",
  beside = TRUE,
  horiz = TRUE,
  offset = m.bdm1,
  las = 1,
  space = c(-1, 1),
  cex.names = 1
)
