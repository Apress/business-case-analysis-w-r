# Define a vector of the Extended Swanson-Megill probability weights. These
# correspond to the values in the sens.range vector.
prob.wts <- c(0.3, 0.4, 0.3)

# Create the 3x3 matrix of the products of the uncertainty branch probabilities.
probs.branch.matrix <- prob.wts %*% t(prob.wts)

# Typically, we run business model for each decision with critical uncertainty
# peak.units.sold set to its respective p10, p50, p90 values. Find the mean NPV
# of the business model at each of these points. However, we already did this in
# the Sensitivity_Analysis.R script, so all we need to do is use the slice of
# the sensitivity table associated with the peak.units.sold row.
bdm1.sens <- npv.sens1[1, ]
bdm2.sens <- npv.sens2[1, ]

# Create a 3x3 matrix of the values in the bdm1.sens and bdm2.sens vectors.
# Transpose the values in the second matrix
bdm1.sens.matrix <- array(rep(bdm1.sens, 3), dim = c(3, 3))
bdm2.sens.matrix <- t(array(rep(bdm2.sens, 3), dim = c(3, 3)))

# Find the parallel maximum value between these matrices. This represents
# knowing the maximum value given the prior information about the combinations
# of the outcomes of each uncertainty.
bdm.sens.prior.info <- pmax(bdm1.sens.matrix, bdm2.sens.matrix)

# Find the expected value of the matrix that contains the decision values with
# prior information. This is the value of knowing the outcome before making a
# decision.
bdm.prior.info <- sum(bdm.sens.prior.info * probs.branch.matrix)

# Find the maximum expected decison value without prior information.
bdm.max.curr.info <- max(mean(bdm1), mean(bdm2))

# The value of information is the net value of knowing
# the outcome beforehand compared to the decison with
# the highest value before the outcome is known.
val.info <- (bdm.prior.info - bdm.max.curr.info)

print("Decision Value [$M]")
value.report <- list("Prior Information" = signif(bdm.prior.info, 3),
                     "Current Information" = signif(bdm.max.curr.info, 3),
                     "Value of Information" = signif(val.info, 3))
print(value.report)
