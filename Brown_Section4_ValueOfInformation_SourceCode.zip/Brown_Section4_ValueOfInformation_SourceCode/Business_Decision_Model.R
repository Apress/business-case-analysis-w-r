# Import function and data source files.
source("/Applications/R/RProjects/Value of Information/Functions.R")
source("/Applications/R/RProjects/Value of Information/Assumptions.R")

# Run the business decision models and return sample outputs of NPV.
bdm1 <-
  CalcBizModel(
    time,
    samps,
    dec1.uncs$peak.units.sold,
    dec1.uncs$time.to.peak,
    dec1.uncs$price,
    dec1.uncs$sga,
    dec1.uncs$cogs,
    tax.rate,
    dec1.uncs$investment,
    disc.rate
  )$npv / 1e6

bdm2 <-
  CalcBizModel(
    time,
    samps,
    dec2.uncs$peak.units.sold,
    dec2.uncs$time.to.peak,
    dec2.uncs$price,
    dec2.uncs$sga,
    dec2.uncs$cogs,
    tax.rate,
    dec2.uncs$investment,
    disc.rate
  )$npv / 1e6

# Calculate the mean NPV of each decision and their difference.
m.bdm1 <- mean(bdm1)
m.bdm2 <- mean(bdm2)
diff.bdm <- mean(bdm2 - bdm1)

# Tabulate the average model results.
m.bdm <- array(c(m.bdm1, m.bdm2), dim=c(2, 1))
colnames(m.bdm) <- "Mean NPV of decision [$M]"
rownames(m.bdm) <- c("Decision1", "Decision2")
print(signif(m.bdm,3))
print(paste("The difference in mean value between strategies:", "$",
            signif(diff.bdm, 3), "M"))

# Plot the cumulative probability distribution of the NPVs.
par(mar = c(12, 5, 5, 2) + .05, xpd = TRUE)
legend.idents <- c("Decision 1", "Decision 2")
plot.ecdf(
  bdm1,
  do.points = TRUE,
  col = "red",
  main = "NPV of Business Decision",
  xlab = "NPV [$M]",
  ylab = "Cumulative Probability",
  xlim = c(min(bdm1, bdm2), max(bdm1, bdm2)),
  tck = 1
)
plot.ecdf(
  bdm2,
  do.points = TRUE,
  add = TRUE,
  col = "blue")
legend(
  "bottom",
  inset = c(0, -.45),
  legend = legend.idents,
  text.width = 2.5,
  ncol = 2,
  pch = c(13, 14),
  col = c("red", "blue")
)
