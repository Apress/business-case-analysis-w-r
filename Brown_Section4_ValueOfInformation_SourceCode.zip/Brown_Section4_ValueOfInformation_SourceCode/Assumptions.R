# time horizon of the model
time.horizon <- 10 # yr
time <- 0:time.horizon

# Ensure reproducible results
set.seed(98)

# number of samples used for the simulation.
samps <- 30000

tax.rate <- 0.35 # %
disc.rate <- 0.10 # %/yr

# Uncertainties have the following units.
# peak.units.sold, max units/year after year 0
# time.to.peak, years
# price, $/unit
# cogs, $/unit
# sga, % revenue
# investment, $ in year 0

# uncertainty paramaters for decision 1
dec1.uncs <- list(
  peak.units.sold = round(CalcBrownJohnson(0, 10000, 12500, 18000, , samps)),
  time.to.peak = CalcBrownJohnson(0, 2, 3, 5, , samps),
  price = CalcBrownJohnson(0, 90, 95, 98, , samps),
  cogs = CalcBrownJohnson(0, 15, 17, 20, , samps),
  sga = CalcBrownJohnson(0, 0.1, 0.12, 0.14, 1, samps),
  investment = CalcBrownJohnson(0, 100000, 115000, 150000, , samps)
)

# uncertainty paramaters for decision 2
dec2.uncs = list(
  peak.units.sold = round(CalcBrownJohnson(0, 9000, 17000, 25000, , samps)),
  time.to.peak = CalcBrownJohnson(0, 2, 4, 6, , samps),
  price = CalcBrownJohnson(0, 95, 100, 103, , samps),
  cogs = CalcBrownJohnson(0, 16, 18, 21, , samps),
  sga = CalcBrownJohnson(0, 0.1, 0.13, 0.16, 1, samps),
  investment = CalcBrownJohnson(0, 135000, 155000, 200000, , samps)
)
