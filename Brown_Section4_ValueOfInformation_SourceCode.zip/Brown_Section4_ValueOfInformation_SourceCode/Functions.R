CalcBrownJohnson <- function(minlim=-Inf, p10, p50, p90, maxlim=Inf, samples) {
	# This function simulates a distribution from three expert estimates
  # for the 80th percentile probability interval of a predicted outcome.
	# The user specifies the three parameters and the number of samples.
  # The user can also enter optional minimum and maximum limits that
  # represent constraints imposed by the system being modeled. These are
  # set to -inf and inf, respectivelly, by default. The process of
  # simulation is simple Monte Carlo with 100 samples by default.

	# Create a uniform variate sample space in the interval (0,1).
	U <- runif(samples, 0, 1)
	lenU <- length(U)
	# Create an index in the interval (1,samples) with samples members.
	Uindex <- 1:lenU

	# Calculates the virtual tails of the distribution given the p10, p50, p90
	# inputs.
	p0 <- pmax(minlim, p50 - 2.5 * (p50 - p10))
	p100 <- pmin(maxlim, p50 + 2.5 * (p90 - p50))

	# This next section finds the linear coefficients of the system of linear
	# equations that describe the linear spline, using... [C](A) = (X) (A) = [C]^-1
	# * (X) In this case, the elements of (C) are found using the values (0, 0.1,
	# 0.5, 0.9, 1) at the end points of each spline segment. The elements of (X)
	# correspond to the values of (p0, p10, p10, p50, p50, p90, p90, p100). Solving
	# for this system of linear equations gives linear coefficients that transform
	# values in U to intermediate values in X. Because there are four segments in
	# the linear spline, and each segment contains two unknowns, a total of eight
	# equations are required to solve the system.

	# The spline knot values in the X domain.
	knot_vector <- c(p0, p10, p10, p50, p50, p90, p90, p100)

	# The solutions to the eight equations at the knot points required to describe
	# the linear system.
	coeff_vals <- c(0, 1, 0, 0, 0, 0, 0, 0,
	               0.1, 1, 0, 0, 0, 0, 0, 0,
	               0, 0, 0.1, 1, 0, 0, 0, 0,
	               0, 0, 0.5, 1, 0, 0, 0, 0,
	               0, 0, 0, 0, 0.5, 1, 0, 0,
	               0, 0, 0, 0, 0.9, 1, 0, 0,
	               0, 0, 0, 0, 0, 0, 0.9, 1,
	               0, 0, 0, 0, 0, 0, 1, 1)

	# The coefficient matrix created from the prior vector. It looks like the
	# following matrix:
		     # [,1] [,2] [,3] [,4] [,5] [,6] [,7] [,8]
	  # [1,]  0.0    1  0.0    0  0.0    0  0.0    0
	  # [2,]  0.1    1  0.0    0  0.0    0  0.0    0
	  # [3,]  0.0    0  0.1    1  0.0    0  0.0    0
	  # [4,]  0.0    0  0.5    1  0.0    0  0.0    0
	  # [5,]  0.0    0  0.0    0  0.5    1  0.0    0
	  # [6,]  0.0    0  0.0    0  0.9    1  0.0    0
	  # [7,]  0.0    0  0.0    0  0.0    0  0.9    1
	  # [8,]  0.0    0  0.0    0  0.0    0  1.0    1

	coeff_matrix <- t(matrix(coeff_vals, nrow=8, ncol=8))

	#The inverse of the coefficient matrix.
	inv_coeff_matrix <- solve(coeff_matrix)

	#The solution vector of the linear coefficients.
	sol_vect <- inv_coeff_matrix %*% knot_vector

	X = (U <= 0.1) * (sol_vect[1, 1] * U + sol_vect[2, 1]) +
	    (U > 0.1 & U <= 0.5) * (sol_vect[3, 1] * U + sol_vect[4, 1]) +
	    (U > 0.5 & U <= 0.9) * (sol_vect[5, 1] * U + sol_vect[6, 1]) +
	    (U > 0.9 & U <= 1) * (sol_vect[7, 1] * U + sol_vect[8, 1])

	return(X)
}

CalcScurv <- function(y0, t, tp, k = 0) {
  # This function models the sigmoid 1 / (1 + exp(-g*t)) with four analytic
  # parameters.
  # y0 = saturation in first period.
  # t = the index along which the s-curve responds, usually thought of as time.
  # k = the offset in t for when the sigmoid begins. Subtract k for a right
  #     shift. Add k for a left shift.
  # tp = the t at which s-curve achieves 1-y0.

  this.s.curve = 1 / (1 + (y0 / (1 - y0)) ^ (2 * (t + k) / tp - 1))
  return(this.s.curve)
}

CalcBizModel <- function(Time, N, pus, ttp, p, sga, cogs, tr, i, dr) {
  # The function that represents the business model reflected by the influence
  # diagram.

	# Time = the time index
	# N = the number of simulation samples
	# pus = peak units sold
	# ttp = time to peak units sold
	# p = price, $/unit
	# sga = sales, general, and admin, % revenue
	# cogs = cost of goods sold, $/unit
	# tr = tax rate, %
	# i = initial investment, $
	# dr = discount rate, %/year

	init <- t(array(0, dim=c(length(Time), N)))
	ann.units.sold <- init
	revenue <- init
	profit <- init
	tax <- init
	cash.flow <- init
	npv <- rep(0, N)
	samp.index <- 1:N
	for (s in samp.index) {
	  # annual units sold
	  ann.units.sold[s, ] <-
	    (Time > min(Time)) * pus[s] * CalcScurv(0.02, Time, ttp[s], -1)

	  # annual period revenue
	  revenue[s, ] <- p[s] * ann.units.sold[s, ]

	  # annual period profit
	  profit[s, ] <-
	    revenue[s, ] - (sga[s] * revenue[s, ]) - (cogs[s] * ann.units.sold[s, ])

	  # annual period tax
	  tax[s, ] <- tr * profit[s, ]

	  # annual period cash flow
	  cash.flow[s, ] <-
	    (Time > min(Time)) * (profit[s, ] - tax[s, ]) - (Time == min(Time)) * i[s]

	  # net present value of the annual period cash flow
	  npv[s] <- sum(cash.flow[s, ] / (1 + dr) ^ Time)
	}

	# Collect all intermediate calculations in a list to be used for other
	# calculations or reporting.
	calc.vals <- list(ann.units.sold = ann.units.sold,
	                     revenue = revenue,
	                     profit = profit,
	                     tax = tax,
	                     cash.flow = cash.flow,
	                     npv = npv
	                  )
	return(calc.vals)
}

CalcModelSensitivity <- function(unc.list, sens.q) {
  # unc.list = A list that contains the uncertain variables' samples used in
  #            the business model.
  # sens.q = a vector that contains sensitivity test quantiles

  # Create an index from 1 to the number of uncertainties used in the business
  # model.
  unc.index <- 1:length(unc.list)

  # Assign the values of the uncertainties list to a temporary list
  uncs.temp <- unc.list

  # Initialize a table to contain mean NPVs of the business model as each
  # uncertainty is set to the sensitivity quantile values.
  sens.table <-
    array(0, dim = c(length(unc.list), length(sens.q)))
  row.names(sens.table) <- names(unc.list)
  colnames(sens.table) <- sens.q

  for (u in unc.index) {
    for (s in 1:length(sens.q)) {

      # Iterate across the uncertainties and elements of the sensitivity
      # quantile values and temporarily replace each uncertainty's samples with
      # the uncertainty's value at each quantile value.
      uncs.temp[[u]] <- rep(quantile(unc.list[[u]], sens.q[s]), samps)

      # Populate the sensitivity table with the mean NPV values calculated in
      # the business model using the values in the temporary uncertainty list.
      sens.table[u, s] <- mean(
        CalcBizModel(
          time,
          samps,
          uncs.temp$peak.units.sold,
          uncs.temp$time.to.peak,
          uncs.temp$price,
          uncs.temp$sga,
          uncs.temp$cogs,
          tax.rate,
          uncs.temp$investment,
          disc.rate
        )$npv
      )
    }
    # Reset the temporary uncertainty list back to the original uncertainty list.
    uncs.temp <- unc.list
  }
  return(sens.table)
}
